import{d as t}from"./style-CnAGp84j.js";const c=["svg",t,[["circle",{cx:"11",cy:"11",r:"8"}],["path",{d:"m21 21-4.3-4.3"}]]];export{c as S};
